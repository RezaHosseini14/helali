import { Controller, Get, Query } from '@nestjs/common';

import { Public } from '@/shared/decorators/public.decorator';

import { TweetsService } from './tweets.service';

@Controller('tweets')
export class TweetsController {
  constructor(private readonly tweetsService: TweetsService) {}

  @Public()
  @Get()
  async findLatest(@Query('limit') limitRaw?: string) {
    const limit = limitRaw ? Number(limitRaw) : undefined;
    const data = await this.tweetsService.findLatest(limit);

    return {
      message: 'توییت‌ها دریافت شد',
      data,
    };
  }
}
